import * as THREE from './three.module.js';

const mount = document.querySelector('#game');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9fc3d5);
scene.fog = new THREE.Fog(0x9fc3d5, 95, 310);
const camera = new THREE.PerspectiveCamera(66, innerWidth/innerHeight, .1, 500);
const renderer = new THREE.WebGLRenderer({antialias:false, powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
mount.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xd9edff,0x52604f,2.0));
const sun = new THREE.DirectionalLight(0xfff0d6,2.1);
sun.position.set(-60,100,40); sun.castShadow=true;
sun.shadow.mapSize.set(1024,1024); sun.shadow.camera.left=-100; sun.shadow.camera.right=100; sun.shadow.camera.top=100; sun.shadow.camera.bottom=-100;
scene.add(sun);

const mat=(c,rough=1)=>new THREE.MeshStandardMaterial({color:c,roughness:rough});
const grass=mat(0x607c60), asphalt=mat(0x303941), sidewalk=mat(0x8b9694), lineMat=mat(0xd9d9c8);
const buildingMats=[0x9babb1,0xc2b6a1,0x687f8d,0xb2a08e,0x788b80].map(c=>mat(c));
const windowMat=new THREE.MeshStandardMaterial({color:0x263f50,metalness:.15,roughness:.3});
const white=mat(0xe8ecec), black=mat(0x18232c), blue=mat(0x1c5d91), red=mat(0xb63737), skin=mat(0xc9906c), pants=mat(0x283747), policeBlue=mat(0x183e65);
function box(w,h,d,m,x,y,z,parent=scene){const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;}
const ground=new THREE.Mesh(new THREE.PlaneGeometry(500,500),grass);ground.rotation.x=-Math.PI/2;ground.position.y=-.08;ground.receiveShadow=true;scene.add(ground);

// City grid: broad roads, sidewalks, blocks, buildings and window bands.
for(let k=-3;k<=3;k++){
  const p=k*42;
  const road1=box(12,.08,300,asphalt,p,.0,0); road1.receiveShadow=true;
  const road2=box(300,.08,12,asphalt,0,.01,p); road2.receiveShadow=true;
  for(let s of [-1,1]){
    box(2,.12,300,sidewalk,p+s*7,.02,0);
    box(300,.12,2,sidewalk,0,.02,p+s*7);
  }
  for(let z=-140;z<150;z+=8) box(.12,.025,3,lineMat,p,.07,z);
  for(let x=-140;x<150;x+=8) box(3,.025,.12,lineMat,x,.07,p);
}
const buildings=[];
for(let gx=-3;gx<=2;gx++) for(let gz=-3;gz<=2;gz++){
  const cx=gx*42+21, cz=gz*42+21;
  for(let n=0;n<3;n++){
    const x=cx+(n-1)*10+(Math.random()-.5)*2, z=cz+(Math.random()-.5)*15;
    const w=7+Math.random()*3,d=8+Math.random()*5,h=12+Math.random()*32;
    const b=box(w,h,d,buildingMats[Math.floor(Math.random()*buildingMats.length)],x,h/2,z);
    buildings.push({x,z,w,d,h});
    // Simple repeated window strips keep the scene light enough for phones.
    for(let yy=3;yy<h-2;yy+=3.5){
      for(let xx=-w/2+1;xx<w/2-0.5;xx+=2){
        box(.9,1.25,.045,windowMat,x+xx,yy,z+d/2+.03);
        box(.9,1.25,.045,windowMat,x+xx,yy,z-d/2-.03);
      }
    }
  }
}
// Street trees and lamps.
const trunk=mat(0x604936), leaves=mat(0x315f45), lampMat=mat(0x27333a);
for(let road=-3;road<=3;road++) for(let n=-3;n<=3;n++){
  const p=road*42, q=n*42+12;
  for(const side of [-1,1]){
    const tx=p+side*9,tz=q;
    box(.45,3,.45,trunk,tx,1.5,tz);
    const crown=new THREE.Mesh(new THREE.IcosahedronGeometry(2.2,1),leaves); crown.position.set(tx,4,tz); crown.castShadow=true;scene.add(crown);
    box(.15,5,.15,lampMat,p+side*8,2.5,q+9);
    box(.8,.18,.5,white,p+side*8,5,q+9);
  }
}

function makePerson(x,z,isPolice=false){
  const g=new THREE.Group(); g.position.set(x,0,z); scene.add(g);
  const shirt=isPolice?policeBlue:mat([0x8b5945,0x466d83,0x6f7651,0x8b8b91][Math.floor(Math.random()*4)]);
  const torso=new THREE.Mesh(new THREE.BoxGeometry(.72,1,.38),shirt);torso.position.y=1.25;torso.castShadow=true;g.add(torso);
  const head=new THREE.Mesh(new THREE.SphereGeometry(.25,10,8),skin);head.position.y=1.95;head.castShadow=true;g.add(head);
  const leg1=new THREE.Mesh(new THREE.BoxGeometry(.25,.78,.28),pants),leg2=leg1.clone();leg1.position.set(-.2,.39,0);leg2.position.set(.2,.39,0);g.add(leg1,leg2);
  const arm1=new THREE.Mesh(new THREE.BoxGeometry(.2,.75,.22),shirt),arm2=arm1.clone();arm1.position.set(-.49,1.25,0);arm2.position.set(.49,1.25,0);g.add(arm1,arm2);
  if(isPolice){const cap= new THREE.Mesh(new THREE.BoxGeometry(.55,.12,.48),blue);cap.position.y=2.19;g.add(cap);const badge=box(.12,.16,.025,mat(0xe2c35c),0,1.4,.205,g);}
  return {group:g,legs:[leg1,leg2],arms:[arm1,arm2],phase:Math.random()*6,speed:.7+Math.random()*.5,origin:new THREE.Vector3(x,0,z),isPolice};
}
const people=[];
for(let i=0;i<32;i++){
  const axis=Math.random()<.5;
  const x=axis? (Math.floor(Math.random()*7)-3)*42+(Math.random()<.5?-9:9) : (Math.random()-.5)*250;
  const z=axis? (Math.random()-.5)*250 : (Math.floor(Math.random()*7)-3)*42+(Math.random()<.5?-9:9);
  people.push(makePerson(x,z,i%9===0));
}

function makeCar(x,z,color=0x263f58,police=false){
  const g=new THREE.Group();g.position.set(x,.2,z);scene.add(g);
  box(2.15,.65,4.2,mat(color),0,.65,0,g);
  box(1.75,.72,2.05,mat(0x9eb7c2,.4),0,1.3,-.1,g);
  for(const sx of [-1,1]) for(const sz of [-1,1]){
    const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.42,.42,.22,12),black);wheel.rotation.z=Math.PI/2;wheel.position.set(sx*1.08,.42,sz*1.35);g.add(wheel);
  }
  for(const sx of [-.72,.72]){box(.42,.18,.08,mat(0xffe5a6),sx,.75,2.12,g);box(.42,.18,.08,red,sx,.75,-2.12,g);}
  if(police){box(.8,.12,.3,red,0,1.75,0,g);box(.35,.13,.3,blue,-.23,1.76,0,g);box(.35,.13,.3,red,.23,1.76,0,g);}
  return {group:g,police};
}
const cars=[
 makeCar(5,.5,0x1c5d91,true),makeCar(-12,10,0xb9c0c3),makeCar(25,-18,0x5d665e),
 makeCar(-28,45,0x8b3935),makeCar(48,20,0x252b35),makeCar(-55,-28,0xb7a16c)
];
let player=makePerson(0,5,false), inCar=false, activeCar=null, speed=0, heading=0, running=false;
const keys={}; addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(e.key==='Shift')running=true;});
addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=false;if(e.key==='Shift')running=false;});
const joy=document.querySelector('#joystick'),stick=document.querySelector('#stick');
let joyX=0,joyY=0,joyOn=false;
function joyMove(e){const r=joy.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),len=Math.min(36,Math.hypot(dx,dy)),a=Math.atan2(dy,dx);joyX=Math.cos(a)*len/36;joyY=Math.sin(a)*len/36;stick.style.transform=`translate(${Math.cos(a)*len}px,${Math.sin(a)*len}px)`;}
joy.addEventListener('pointerdown',e=>{joyOn=true;joy.setPointerCapture(e.pointerId);joyMove(e)});
joy.addEventListener('pointermove',e=>{if(joyOn)joyMove(e)});
function joyEnd(){joyOn=false;joyX=joyY=0;stick.style.transform='translate(0,0)'}
joy.addEventListener('pointerup',joyEnd);joy.addEventListener('pointercancel',joyEnd);
document.querySelector('#runBtn').addEventListener('pointerdown',()=>running=true);
document.querySelector('#runBtn').addEventListener('pointerup',()=>running=false);
document.querySelector('#runBtn').addEventListener('pointerleave',()=>running=false);
function toast(t){const el=document.querySelector('#toast');el.textContent=t;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),1800);}
function nearestCar(){let best=null,d=5;for(const c of cars){const q=c.group.position.distanceTo(player.group.position);if(q<d){d=q;best=c;}}return best;}
document.querySelector('#enterBtn').onclick=()=>{
 if(inCar)return;
 const c=nearestCar();if(!c){toast('Подойди ближе к машине');return;}
 activeCar=c;inCar=true;player.group.visible=false;document.querySelector('#vehicleStatus').textContent=c.police?'Патрульная машина':'Личный автомобиль';toast('Ты сел в автомобиль');
};
document.querySelector('#exitBtn').onclick=()=>{
 if(!inCar)return;
 player.group.position.copy(activeCar.group.position).add(new THREE.Vector3(2,0,0));player.group.visible=true;inCar=false;activeCar=null;toast('Ты вышел из машины');
};
const clock=new THREE.Clock();
function update(dt){
 const forward=(keys.w||keys.arrowup?1:0)-(keys.s||keys.arrowdown?1:0)-joyY;
 const turn=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0)+joyX;
 if(inCar&&activeCar){
   heading-=turn*dt*1.7;
   speed+=(forward*19-speed*2.5)*dt;
   speed=THREE.MathUtils.clamp(speed,-8,22);
   activeCar.group.rotation.y=heading;
   activeCar.group.position.x+=Math.sin(heading)*speed*dt;
   activeCar.group.position.z+=Math.cos(heading)*speed*dt;
   activeCar.group.position.x=THREE.MathUtils.clamp(activeCar.group.position.x,-145,145);
   activeCar.group.position.z=THREE.MathUtils.clamp(activeCar.group.position.z,-145,145);
 }else{
   const moving=Math.abs(forward)+Math.abs(turn)>.05;
   if(moving){heading=Math.atan2(turn,Math.max(.1,forward));const v=running?9:5;player.group.position.x+=Math.sin(heading)*v*dt;player.group.position.z+=Math.cos(heading)*v*dt;player.group.rotation.y=heading;}
   player.phase=(player.phase||0)+dt*(moving?12:2);
   const swing=Math.sin(player.phase)*.38*(moving?1:0);
   player.legs[0].rotation.x=swing;player.legs[1].rotation.x=-swing;
   player.arms[0].rotation.x=-swing*.6;player.arms[1].rotation.x=swing*.6;
 }
 // Pedestrians follow short sidewalk routes; police are visibly identifiable patrol NPCs.
 for(const p of people){
   p.phase+=dt*p.speed;
   const a=p.phase*.22+(p.isPolice?1:0);
   p.group.position.x=p.origin.x+Math.sin(a)*5;
   p.group.position.z=p.origin.z+Math.cos(a)*5;
   p.group.rotation.y=Math.atan2(Math.cos(a),-Math.sin(a));
   const sw=Math.sin(p.phase*3)*.25;p.legs[0].rotation.x=sw;p.legs[1].rotation.x=-sw;
 }
}
function animate(){
 requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);update(dt);
 const target=inCar?activeCar.group.position:player.group.position;
 const dist= inCar?10:8, height=inCar?5:6;
 const desired=new THREE.Vector3(target.x-Math.sin(heading)*dist,target.y+height,target.z-Math.cos(heading)*dist);
 camera.position.lerp(desired,.09);camera.lookAt(target.x,target.y+1.1,target.z);
 const c=nearestCar();document.querySelector('#hint').textContent=inCar?'Управление: джойстик или WASD':(c?'Рядом автомобиль — нажми «Сесть»':'Исследуй город и найди автомобиль');
 renderer.render(scene,camera);
}
animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
